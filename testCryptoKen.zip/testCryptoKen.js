//Both key obtained through URSA then JWKed by PEM2JWK
//PUBLIC
var Key = { kty: 'RSA',
  n: 'xZcpN2o9-qxEhEvtJBQyZw0r2U8MWfg0r_41QRopDyAwyMFQoXO2_oAaB-80iq7XkNy78SkS-gJfaAmTcSLModP65EV2mrVidQa5QIzj_oVmocBcv0IaHvHvBqhZ5Txt0VvdcgGdDNLiaxREgK3yrVw7nPtzWcQ9q-6zy_Df-pE',
  e: 'AQAB' }
//SECRET
var Secret = { kty: 'RSA',
  n: 'xZcpN2o9-qxEhEvtJBQyZw0r2U8MWfg0r_41QRopDyAwyMFQoXO2_oAaB-80iq7XkNy78SkS-gJfaAmTcSLModP65EV2mrVidQa5QIzj_oVmocBcv0IaHvHvBqhZ5Txt0VvdcgGdDNLiaxREgK3yrVw7nPtzWcQ9q-6zy_Df-pE',
  e: 'AQAB',
  d: 'voIkRz20TIDT_wqFtoeSoTFd2cQRkJ1zj0x2ZDKo6-CJqMZay5AaG_-_GW9VJXG2fgGVY8vKdCrdeh3hfu-ig6Lt_JNL25x553croALGHOvaxvZlpvPrfxwcC3wxU4fy8r3u2COisr8bQkXZvXzWSY5ownDSiqUj_ie296kt2AE',
  p: '7MBoMlAXB88e56DUNDt3dE64aZ4Qfjt6q0fKKZuoazlqF9oceP6rymG4O7b2e5S_9HWVy2hHqkairxmNLTmPcQ',
  q: '1aeuGKiZ6ShMcT7NKkTt3f-TUJFqOaiI_MJVbz9M1uIAz2xnI50jRC4LX2ZTLzlTTaxSkds3u21OuRuNYIfNIQ',
  dp: 'sI6EphDIPBCgMYjk99bpLJmQOWOhVSIyRw2QnBrzLJNypTsJRMpXfuQFKrM1ec_inwIZpcmsuDVZGU_q0rE8YQ',
  dq: 'ENXBlhfS6NhQDaxRJj-ALrnwtax_nkN1Z9U4PifSuivcvHtiNSAwozKtmrrJWzM9KSWm6-9GGPKn_VX6cdzBgQ',
  qi: '4CKNYzY_mAI-aBA98esujBCciOEBXihLmXa-R_vo2QFOvflBq1l_RI9GHzeuDIwWDF-9hXhLhr4OMtQPgaRrFA' }

// Problem
// jwk2pem(pem2jwk(key)) != key

 function str2ab(str) {
   var buf = new ArrayBuffer(str.length*2); // 2 bytes for each char
   var bufView = new Uint16Array(buf);
   for (var i=0, strLen=str.length; i < strLen; i++) {
     bufView[i] = str.charCodeAt(i);
   }
   return buf;
 }


// Token
var payload = {foo: 'bar'}
var header = {typ: "JWT", alg: "RS256"}
var data = btoa(JSON.stringify(header))+"."+btoa(JSON.stringify(payload))
console.log(data)

crypto.subtle.importKey('jwk',Secret,{ name: 'RSASSA-PKCS1-v1_5',hash: {name: "SHA-256"}},true, ['sign'])
    .then(JWKS =>
        crypto.subtle.importKey('jwk',Key,{ name: 'RSASSA-PKCS1-v1_5',hash: {name: "SHA-256"}},true, ['verify'])
    .then(JWKP =>
        crypto.subtle.sign('RSASSA-PKCS1-v1_5', JWKS, str2ab(data))
    .then(signature => {
        console.log(signature)
        crypto.subtle.verify({name: "RSASSA-PKCS1-v1_5"},
            JWKP, //from generateKey or importKey above
            signature, //ArrayBuffer of the signature
            str2ab(data)) //ArrayBuffer of the data)
    .then(valid => console.log("Token validate: "+valid))
    .catch(err => console.error(err))
})))
